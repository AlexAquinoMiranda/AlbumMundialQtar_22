package com.example.proyectoalexisandroid.Data;

import android.util.Log;

public class Helper {
    public FicheroAllJugadores getFichero() {
        return fichero;
    }

    public static  FicheroAllJugadores fichero;

    public void rellenoJugadores() {
        fichero = new FicheroAllJugadores();
        int dorsal = 1;
        fichero.addJugador(new Jugador("Leandro", "Parédez", "leoparedez", "argentina", false, dorsal));
        fichero.addJugador(new Jugador("Leo", "Messi", "messi", "argentina", false, dorsal));
        fichero.addJugador(new Jugador("Killiam", "Mbappé", "mbappe", "france", false, dorsal));
        fichero.addJugador(new Jugador("Cristiano", "Ronaldo", "cristiano", "france", false, dorsal));
        fichero.addJugador(new Jugador("Neymar", "Jr", "neymar", "brazil", false, dorsal));
        fichero.addJugador(new Jugador("Vinnicius", "Jr", "vini", "brazil", false, dorsal));
        fichero.addJugador(new Jugador("Emiliano", "Martínez", "emilio", "argentina", false, dorsal));
        fichero.addJugador(new Jugador("Julián", "Álvarez", "julian", "argentina", false, dorsal));
        fichero.addJugador(new Jugador("Antoine", "Griezman", "griezman", "france", false, dorsal));
        fichero.addJugador(new Jugador("Robert", "Lewandowski", "robert", "brazil", false, dorsal));
        fichero.addJugador(new Jugador("Luka", "Modrich", "luka", "croatia", false, dorsal));
        fichero.addJugador(new Jugador("Luis", "Suarez", "suarez", "croatia", false, dorsal));
        Log.i("----", "Cargando datos de juagdores");

                System.out.println(fichero.findId(1).toString());
    }

    public Jugador obtenerJugador(int i){
      return this.fichero.findId(i);
    }
}

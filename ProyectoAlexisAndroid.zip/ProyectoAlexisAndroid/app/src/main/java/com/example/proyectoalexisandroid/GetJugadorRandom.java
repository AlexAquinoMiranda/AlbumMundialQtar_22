package com.example.proyectoalexisandroid;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.proyectoalexisandroid.Data.Helper;
import com.example.proyectoalexisandroid.Data.Jugador;

import java.util.ArrayList;
import java.util.Random;

public class GetJugadorRandom extends AppCompatActivity {
    Button btnComprarToken;
    Button btnObtenerJugador;
    TextView cantidadTokens;
    TextView nombreObtenido;
    ImageView imagenJugador;
    FloatingActionButton atras;

    public ArrayList<Jugador> getMisJugadores() {
        return misJugadores;
    }

  public static  ArrayList<Jugador> misJugadores = new ArrayList<>();
    static int tokenActual = CompraToken.unidadToken;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_jugador_random);

        btnObtenerJugador = findViewById(R.id.btnGetPlayer);
        nombreObtenido = findViewById(R.id.NombreObtenido);
        atras = findViewById(R.id.getAtras);
        btnComprarToken = findViewById(R.id.btnObtenerToken);
        cantidadTokens = findViewById(R.id.CantidadTokens);
        imagenJugador = findViewById(R.id.imagenPlayer);
        cantidadTokens.setText(String.valueOf(CompraToken.unidadToken));

        eventos();


    }

    void obtenerJugador() {
        Helper e = new Helper();
        e.rellenoJugadores();
        ArrayList<Jugador> jugadores = e.getFichero().allPlayer();

        Random r = new Random();
        int value = r.nextInt(10);//longitud de la lista de jugadores disponibles
        System.out.println(value + " es el valor obtenidp random");
        Jugador ale = jugadores.get(value);
        boolean cond = false;
        if (misJugadores.contains(ale) == false) {
            for (Jugador a : misJugadores) {
                if (a.getNombre() == ale.getNombre() && a.getApellido() == ale.getApellido()) {
                    System.out.println("YA ESTA EN LA LISTA");
                    cond = true;
                    break;
                }
            }
            if(cond== false){
                misJugadores.add(ale);
                System.out.println("se agrego a mi lista");
            }

        }


        //Jugador obtenido tengo que agregarlo a una lista.
        //dicha lista voy a mostrar en list my players.
        String uri = "@drawable/" + ale.getImagen();// datos[value];
        int imageResource = getResources().getIdentifier(uri, null, getPackageName());
        Drawable imagen = ContextCompat.getDrawable(getApplicationContext(), imageResource);
        imagenJugador.setImageDrawable(imagen);
        //imgJugador.setImageResource(drawable.messileo);
        nombreObtenido.setText(ale.getNombre() + "  " + ale.getApellido());
        Log.i("----random ", ale.toString());
        //comprueba si ya existe en la lista y en otro caso lo agrego.


    }
void sinToken(){

    AlertDialog.Builder dialogo = new AlertDialog.Builder(this);

    dialogo.setTitle("Información");
    dialogo.setMessage("Te has quedado sin tokens \n ¿Deseas comprar?");
    dialogo.setPositiveButton("Sí", new DialogInterface.OnClickListener() {
        public void onClick(DialogInterface dialog, int which) {
            System.out.println("se va a comprar");
            Intent myIntent = new Intent(GetJugadorRandom.this, CompraToken.class);
            startActivity(myIntent);
            dialog.cancel();
        }
    });
    dialogo.setNegativeButton("No", new DialogInterface.OnClickListener() {
        public void onClick(DialogInterface dialog, int which) {
            dialog.cancel();
        }
    });

    dialogo.create();

    dialogo.show();
}

    private void eventos() {
        imagenJugador.setImageResource(R.drawable.leoparedez);
        atras.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(GetJugadorRandom.this, Home.class);
                startActivity(myIntent);
            }
        });
        btnComprarToken.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(GetJugadorRandom.this, CompraToken.class);
                startActivity(myIntent);
            }
        });

        //obtienes jugador
        btnObtenerJugador.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (CompraToken.unidadToken == 0) {
                    Log.i("----", "sin tokennnnnnn");
                    sinToken();
                    //  Toast.makeText(this, "Tokens insuficientes, realiza una compra.", Toast.LENGTH_SHORT).show();

                } else {
                    obtenerJugador();
                    CompraToken.unidadToken--;
                    Log.i("--", " Jugador obtenido");
                    Log.i("---tag---", "obtener jugador");
                    cantidadTokens.setText(String.valueOf(CompraToken.unidadToken));
                }


                //code
            }
        });


    }
}
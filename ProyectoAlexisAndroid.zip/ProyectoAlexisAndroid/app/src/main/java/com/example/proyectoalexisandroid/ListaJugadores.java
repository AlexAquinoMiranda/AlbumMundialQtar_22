package com.example.proyectoalexisandroid;

import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;

import com.example.proyectoalexisandroid.Adaptador.JugadorAdapter;
import com.example.proyectoalexisandroid.Data.FicheroAllJugadores;
import com.example.proyectoalexisandroid.Data.Helper;
import com.example.proyectoalexisandroid.Data.Jugador;

import java.util.ArrayList;

public class ListaJugadores extends AppCompatActivity {
    RecyclerView recyclerView;
    ArrayList<String> listaJugadores;
    FloatingActionButton atras;
    public static Helper helper;
    public static FicheroAllJugadores fichero;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_jugadores);

        atras = findViewById(R.id.listaAtras);
        atras.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(ListaJugadores.this, Home.class);
                startActivity(myIntent);
            }
        });
        recyclerView = findViewById(R.id.recicler);
        //helper = new Helper();
        //helper.rellenoJugadores();
        //helper.getFichero().escribirFichero();
        //ya tengo almacenado supuestamente en el fichero y solo lo cargo a mi lista
        //y le paso esa lista al recycler
        FicheroAllJugadores f = new FicheroAllJugadores();
        f.load();

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        JugadorAdapter adapter = new JugadorAdapter(f.allPlayer(), this);
        recyclerView.setAdapter(adapter);




    }
}
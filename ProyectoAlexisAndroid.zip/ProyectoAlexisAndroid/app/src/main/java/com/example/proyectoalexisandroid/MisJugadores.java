package com.example.proyectoalexisandroid;

import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.example.proyectoalexisandroid.Adaptador.JugadorAdapter;
import com.example.proyectoalexisandroid.Adaptador.MisJugadoresAdapter;
import com.example.proyectoalexisandroid.Data.Helper;
import com.example.proyectoalexisandroid.Data.Jugador;

import java.util.ArrayList;

public class MisJugadores extends AppCompatActivity {
    RecyclerView recyclerView;
    FloatingActionButton atras;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mis_jugadores);
        recyclerView = findViewById(R.id.rcMisJugadores);

        atras = findViewById(R.id.floatingActionAtras);
        atras.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(MisJugadores.this, Home.class);
                startActivity(myIntent);
            }
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
//me falta el array.
        Helper helper = new Helper();
        helper.rellenoJugadores();


        ArrayList<Jugador> lista = GetJugadorRandom.misJugadores;
        if(lista != null){
            MisJugadoresAdapter adapter = new MisJugadoresAdapter(lista, this);
            recyclerView.setAdapter(adapter);
        }





    }
}